# surfcolour.r
# Main 3D back-surface reconstruction from back.jpg using FTP.
# Writes: surfdata.Rdata, pixels.txt, blobs.raw, blobdata.txt,
#         gruvred.raw, uvdata.txt

rm(list=ls())
times <- Sys.time()
graphics.off()

source("setup_helpers.r")
if (!requireNamespace("jpeg", quietly = TRUE)) install.packages("jpeg")
library(jpeg)

safe_dyn_load(c("OxtersDLL/Debug/oxtersDLL.dll",
                "OxtersDLL/Debug/oxtersDLL.so",
                "OxtersDLL/Debug/oxtersDLL.dylib",
                "blobsDLL/Debug/blobsDLL.dll",
                "blobsDLL/Debug/blobsDLL.so",
                "blobsDLL/Debug/blobsDLL.dylib"))

mycol <- load_mycol("mycol.Rdata")

# ---------- local helper functions ----------
meshplot <- function(a) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/60))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  persp(seq(1, ncol(aplot)), seq(1, nrow(aplot)),
        fliplr(t(aplot)), theta=0, phi=40, expand=0.5,
        asp=1, axes=FALSE, box=FALSE)
}

mycontourplot <- function(a, col1=mycol, xpixel=1, ypixel=1) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/120))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  xplot <- seq(1, ncol(aplot)) * xpixel * fact
  yplot <- seq(1, nrow(aplot)) * ypixel * fact
  maxaplot <- round(max(aplot, na.rm=TRUE)/10)*10
  image(xplot, yplot, fliplr(t(aplot)), asp=1, xlab="", ylab="",
        axes=FALSE, col=col1)
  contour(xplot, yplot, fliplr(t(aplot)),
          levels=seq((maxaplot-100), maxaplot, by=5),
          asp=1, add=TRUE, axes=FALSE)
}

myimage <- function(a, xpixel=1, ypixel=1) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/120))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  image(seq(1, ncol(aplot))*xpixel*fact, seq(1, nrow(aplot))*ypixel*fact,
        fliplr(t(aplot)), asp=1, xlab="", ylab="")
}

bamplot <- function(a, col1=mycol, limit=c(0,50)) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/120))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  filled.contour(seq(1, ncol(aplot))*fact, seq(1, nrow(aplot))*fact,
                 fliplr(t(aplot)), asp=1, zlim=limit,
                 xlab="", ylab="", axes=FALSE, col=col1)
}

mypoly <- function(p, myx, myy) {
  yy <- p[1]+p[2]*myx+p[3]*myx^2+p[4]*myx^3+p[5]*myx^4+p[6]*myx^5
  sum((yy-myy)^2)
}

polyval <- function(p, x) {
  nc <- length(p); p <- fliplr(p)
  y <- seq(1, length(x))*0
  if (length(p) > 0) y[] <- p[1]
  for (ii in 2:nc) y <- x*y + p[ii]
  y
}

hanning <- function(n) {
  if (n %% 2) {
    half <- (n+1)/2
    w <- 0.5*(1-cos(2*pi*(1:half)/(n+1)))
    c(w, fliplr(w[1:(length(w)-1)]))
  } else {
    half <- n/2
    w <- 0.5*(1-cos(2*pi*(1:half)/(n+1)))
    c(w, fliplr(w))
  }
}

backrglplot <- function(surf) {
  if (!requireNamespace("rgl", quietly = TRUE)) return(invisible(NULL))
  sizeh <- nrow(surf); sizew <- ncol(surf)
  nr.seq <- seq(1, sizeh, 2); nc.seq <- seq(sizew, 1, -2)
  htemp <- surf[nr.seq, nc.seq]
  colorlut <- heat.colors(256)
  col <- colorlut[256 - 255*(htemp-min(htemp))/(max(htemp)-min(htemp))]
  rgl::rgl.surface(1:length(nr.seq), 1:length(nc.seq), htemp/2, col)
}

find_end <- function(x, frame=1, level=0) {
  n <- length(x)
  for (i in 1:(n-frame+1))
    if (all(x[i:(i+frame-1)] < level)) return(i)
  0
}
find_end2 <- function(x, frame=1, level=0) {
  n <- length(x)
  for (i in 1:(n-frame+1))
    if (all(x[i:(i+frame-1)] > level)) return(i)
  0
}

unwrap <- function(p, cutoff) {
  vecflag <- 0
  if (is.vector(p)) { p <- as.matrix(p); vecflag <- 1 }
  nrows <- nrow(p); ncols <- ncol(p)
  b <- matrix(0, nrow=nrows, ncol=ncols)
  b[2:nrows,] <- diff(p)
  c_ <- -(b > cutoff)
  d_ <- (b < -cutoff)
  e <- (c_ + d_) * 2 * pi
  f <- apply(e, 2, cumsum)
  jump <- round(b[2,]/(2*pi))
  jump1 <- ifelse(jump < 2, 0, jump-1)
  jump2 <- ifelse(jump > -2, 0, jump+1)
  jump3 <- (jump1+jump2)*-2*pi
  jump4 <- matrix(jump3, nrow=nrows, ncol=ncols, byrow=TRUE)
  jump4[1,] <- 0
  q <- p + f + jump4
  if (vecflag) q <- as.vector(q)
  q
}

# ---------- main program ----------
l0 <- 2200
d0 <- 468
theta <- atan(d0/l0)

time1 <- Sys.time()

load("refdata.Rdata")   # provides gr0, deltapix0, f0

grgb <- read_jpeg_rgb("back.jpg")
gr <- grgb[,,2]
time2 <- Sys.time()

imh0 <- nrow(gr); imw0 <- ncol(gr)
centreh0 <- round(imh0/2); centrew0 <- round(imw0/2)
fringepix <- round(1/(deltapix0*f0))
flt <- c(1:fringepix)*0 + 1

tmp1 <- filter(gr, flt, method="convolution", sides=2, circular=TRUE)/length(flt)
mask0 <- thresholding(tmp1, mode="fixed", th=0.24)

tmp <- mask0[, centrew0]
toplim1 <- centreh0+50+1 - which.min(tmp[(centreh0+50):1])
bottomlim1 <- centreh0+50-1 + which.min(tmp[(centreh0+50):imh0])
rlimlev <- round(toplim1 + 0.25*(bottomlim1 - toplim1))
tmp2 <- mask0[rlimlev, ]
leftlim1  <- centrew0 - which.min(tmp2[(centrew0-1):1])
rightlim1 <- centrew0 + which.min(tmp2[centrew0:imw0]) - 1

tmp3 <- mask0[, round((leftlim1+rightlim1)/2)]
toplim <- centreh0+50+1 - which.min(tmp3[(centreh0+50):1])
bottomlim <- centreh0+50-1 + which.min(tmp3[(centreh0+50):imh0])
rlimlev <- round(toplim + 0.25*(bottomlim - toplim))
tmp4 <- mask0[rlimlev, ]
leftlim  <- centrew0 - which.min(tmp4[(centrew0-1):1])
rightlim <- centrew0 + which.min(tmp4[centrew0:imw0]) - 1
time3 <- Sys.time()

deltan0 <- bottomlim - toplim
fftwidth <- c(512, 640, 768, 896, 960, 1024, 1152, 1280, 1408, 1536, 1664)
deltan1 <- deltan0 + 10 - fftwidth
negposcode <- ifelse(deltan1 > 0, 1, 0)
pos <- which.min(negposcode)
fftw <- fftwidth[pos]
imw <- rightlim - leftlim + 1
diftb <- deltan0 - fftw
toplim0 <- toplim + trunc(diftb/2)
time4 <- Sys.time()

g <- imcrop(gr, toplim0, leftlim, fftw, imw)
time5 <- Sys.time()
mask <- imcrop(mask0, toplim0, leftlim, fftw, imw)
time6 <- Sys.time()

zerolim <- trunc(-diftb/2)
if (zerolim < trunc(length(flt)/2)) zerolim <- trunc(length(flt)/2)
mask[1:zerolim, ] <- 0
mask[(fftw-zerolim+1):fftw, ] <- 0
time7 <- Sys.time()

g0 <- imcrop(gr0, toplim0, leftlim, fftw, imw)
time9 <- Sys.time()

mask4 <- mask
mask5 <- mask4
time11 <- Sys.time()

subh <- round(fftw/4); subw <- round(imw/3)
left  <- imcrop(mask4, subh, 1, 2*subh, subw)
right <- imcrop(mask4, subh, imw-subw+1, 2*subh, subw)
test1  <- diff(t(left))
test1a <- diff(t(right))
test4 <- apply(abs(test1), 2, sum)
test5 <- apply(abs(test1a), 2, sum)

ytemp <- find_end(fliplr(test4), 2, 1)
if (ytemp == 0) ytemp <- length(test4)
posloxy <- 3*subh - ytemp + 1

ytemp <- find_end(fliplr(test5), 2, 1)
if (ytemp == 0) ytemp <- length(test5)
posroxy <- 3*subh - ytemp + 1

test6 <- mask4[posloxy, 6:round(imw/2)]
ytemp <- find_end(test6, 1, 1)
posloxx <- ytemp + 5

test7 <- fliplr(mask4[posroxy, round(imw/2):(imw-6)])
ytemp <- find_end(test7, 1, 1)
posroxx <- imw - ytemp - 5

mask5[posloxy:(posloxy+100), 1:(posloxx+5)] <- 0
mask5[posroxy:(posroxy+100), (posroxx-5):imw] <- 0

tempmask <- mask4[(posloxy+101):fftw, 1:(posloxx+5)]
tempmask <- fliplr(tempmask)
tempmask2 <- excise(tempmask)
tempmask2 <- fliplr(tempmask2)
mask5[(posloxy+101):fftw, 1:(posloxx+5)] <- tempmask2

tempmask <- mask4[(posroxy+101):fftw, (posroxx-5):imw]
tempmask2 <- excise(tempmask)
mask5[(posroxy+101):fftw, (posroxx-5):imw] <- tempmask2
time12 <- Sys.time()

myang <- 30/57.2957795

myy <- 1:posloxy
myx1 <- fliplr(round(posloxx - myy*tan(myang)))
myx <- ifelse(myx1 > 0, myx1, 1)
for (i in 1:posloxy) mask5[i, 1:myx[i]] <- 0

myy <- 1:posroxy
myx1 <- fliplr(round(posroxx + myy*tan(myang)))
myx <- ifelse(myx1 > imw, imw, myx1)
for (i in 1:posroxy) mask5[i, myx[i]:imw] <- 0

imh <- fftw
centrew <- trunc(imw/2)
centreh <- trunc(imh/2)

fref <- mvfft(g0)
compfref <- apply(Mod(fref), 1, max)
k1 <- which.max(compfref[10:(imh/2)])
k1 <- k1 + 9
time13 <- Sys.time()

f <- mvfft(g)
time14 <- Sys.time()

filtfjb <- matrix(0, imh, imw)
bw <- round(0.7*k1)
klow <- k1 - bw
khigh <- k1 + bw
filtwind <- hanning(2*bw+1)
for (k in klow:khigh) filtfjb[k, ] <- filtwind[k-klow+1]
time15 <- Sys.time()

ffilt    <- f    * filtfjb
ffiltref <- fref * filtfjb
time16 <- Sys.time()

invf  <- mvfft(ffilt, inverse=TRUE)
invf0 <- mvfft(ffiltref, inverse=TRUE)
time17 <- Sys.time()

phase <- -Im(log(invf * Conj(invf0)))
time18 <- Sys.time()

centreh <- round(fftw/2)
centrew <- round(imw/2)

line1c <- flipud(phase[1:centreh, centrew])
line2c <- phase[centreh:imh, centrew]
line3c <- unwrap(line1c, 3.6)
line6c <- unwrap(line2c, 3.6)
line4c <- flipud(line3c)
line5c <- line4c[1:(centreh-1)]
line7c <- c(line5c, line6c)
phase[, centrew] <- line7c

phasel <- t(phase[, centrew:1])
phaser <- t(phase[, centrew:imw])
uphasel <- fliplr(t(unwrap(phasel, 3.6)))
uphaser <- t(unwrap(phaser, 3.6))
uphase <- cbind(uphasel, uphaser[, 2:ncol(uphaser)])
time19 <- Sys.time()

toptemp    <- round(imh/8)
bottomtemp <- round(imh/2)
lefttemp   <- round(imw*3/16)
righttemp  <- round(imw*13/16)
tempphase  <- uphase[toptemp:bottomtemp, lefttemp:righttemp]
mintemp    <- min(tempphase)
deltatemp  <- -33 - mintemp
ntemp      <- round(deltatemp/(2*pi))
shiftphase <- ntemp*2*pi
uphase <- uphase + shiftphase
time20 <- Sys.time()

h <- l0*uphase/(uphase - 2*pi*f0*d0)
time21 <- Sys.time()

flt2 <- c(1:40)*0 + 1
h1 <- filter(h, flt2, method="convolution", sides=2, circular=TRUE)/length(flt2)
time23 <- Sys.time()

h2 <- h1 * mask5
time22 <- Sys.time()

fact <- 2
if (fftw < 600) fact <- 1
if (fftw > 1600) fact <- 3
deltapix <- deltapix0*fact
nr.seq <- seq(1, imh, fact)
nc.seq <- seq(1, imw, fact)
h3 <- h2[nr.seq, nc.seq]
sizeh <- nrow(h3)
sizew <- ncol(h3)
x1 <- seq(deltapix, deltapix*sizew, deltapix)
y1 <- seq(deltapix, deltapix*sizeh, deltapix)
time24 <- Sys.time()

maskred <- mask5[nr.seq, nc.seq]
maskred[maskred < 0.1] <- NaN
time25 <- Sys.time()

gruv <- grgb[,,3] - 0.9*(grgb[,,1])
time26 <- Sys.time()

gruvred <- imcrop(gruv, toplim0, leftlim, fftw, imw)
gruvred[gruvred < 0] <- 0

newimw <- round(imw*0.5)
startpix <- round(imw*0.25)
uvreduced2 <- gruvred[, startpix:(startpix+newimw-1)]
uvreduced <- filter(uvreduced2, flt, method="convolution", sides=2, circular=TRUE)/length(flt)
time27 <- Sys.time()

thresh <- 0.1
test1uv <- thresholding(uvreduced, mode="fixed", thresh)
if (sum(test1uv) > 6000) {
  thresh <- 0.2
  test1uv <- thresholding(uvreduced, mode="fixed", thresh)
  if (sum(test1uv) > 6000) {
    thresh <- 0.3
    test1uv <- thresholding(uvreduced, mode="fixed", thresh)
    if (sum(test1uv) > 6000) {
      thresh <- 0.4
      test1uv <- thresholding(uvreduced, mode="fixed", thresh)
    }
  }
}
test3uv <- bwlabel2(test1uv)
num <- max(test3uv)
time28 <- Sys.time()

npixels <- matrix(0, 1, num)
rbar <- matrix(0, 1, num)
cbar <- matrix(0, 1, num)
for (j in 1:num) {
  temp <- which(test3uv == j)/imh
  c_ <- ceiling(temp)
  r_ <- round((temp + 1 - c_)*imh)
  npixels[j] <- length(c_)
  rbar[j] <- sum(r_)/npixels[j]
  cbar[j] <- sum(c_)/npixels[j]
}
skiplog <- matrix(0, 1, num)
for (j in 1:num) if (npixels[j] > 40) skiplog[j] <- 1
num2 <- sum(skiplog)

offset1 <- 0
cbar2 <- matrix(0, 1, num2)
rbar2 <- matrix(0, 1, num2)
for (j in 1:num) {
  if (skiplog[j]) {
    rbar2[j-offset1] <- rbar[j]
    cbar2[j-offset1] <- cbar[j]
  } else {
    offset1 <- offset1 + 1
  }
}
cbar2 <- cbar2 + startpix - 1
time28b <- Sys.time()

zz <- file("blobs.raw", "wb")
writeBin(as.integer(as.vector(t(test1uv*255))), zz, size=1)
close(zz)
time29 <- Sys.time()

zz <- file("blobdata.txt", "wt")
write(c(imh, newimw, num2, thresh), zz)
close(zz)
time30 <- Sys.time()

zz <- file("gruvred.raw", "wb")
writeBin(as.integer(as.vector(gruvred*255)), zz, size=1)
close(zz)
time31 <- Sys.time()

zz <- file("uvdata.txt", "wt")
write(c(leftlim, toplim0, imh, imw, length(flt)), zz)
close(zz)
time32 <- Sys.time()

save(h3, x1, y1, maskred, imw, imh, fact, deltapix, sizew, sizeh,
     leftlim, toplim0, file="surfdata.Rdata")
time33 <- Sys.time()

zz <- file("pixels.txt", "wt")
outputdata <- cbind(t(cbar2), t(rbar2))
write.table(outputdata, zz, col.names=FALSE, row.names=FALSE)
close(zz)
time34 <- Sys.time()

deltat <- (time34 - times)
cat(sprintf('Processing time is %g\n', deltat))
cat(sprintf('Run completed successfully\n'))
# END