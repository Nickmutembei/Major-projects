
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the OO_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// OO_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef OO_EXPORTS
#define OO_API __declspec(dllexport)
#else
#define OO_API __declspec(dllimport)
#endif

// This class is exported from the oo.dll
class OO_API COo {
public:
	COo(void);
	// TODO: add your methods here.
};

extern OO_API int nOo;

OO_API int fnOo(void);

