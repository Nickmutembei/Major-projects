# blob.r
# Re-thresholds the UV image and writes blob locations for SuperCard.

rm(list=ls())
times <- Sys.time()

source("setup_helpers.r")
if (!requireNamespace("jpeg", quietly = TRUE)) install.packages("jpeg")
library(jpeg)

safe_dyn_load(c("blobs/build/blobs.dylib",
                "blobs/build/blobs.dll",
                "blobs/build/blobs.so"))

mycol <- load_mycol("mycol.Rdata")

outdir <- ensure_dir("rdata")

# ---------- local helpers ----------
myimage <- function(a, xpixel=1, ypixel=1) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/120))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  image(seq(1, ncol(aplot))*xpixel*fact, seq(1, nrow(aplot))*ypixel*fact,
        fliplr(t(aplot)), asp=1, xlab="", ylab="")
}

# ---------- main ----------
time1 <- Sys.time()

temp <- read.table("uvdata.txt")
imh <- temp$V3
imw <- temp$V4
len <- imh*imw
flt <- c(1:temp$V5)*0 + 1
time2 <- Sys.time()

zz <- file("gruvred.raw", "rb")
temp <- readBin(zz, integer(), n=len, size=1, signed=FALSE)
close(zz)
gruvred <- matrix(temp, imh, imw)
time3 <- Sys.time()

temp <- read.table("threshwidth.txt")
thresh <- temp$V1
width  <- temp$V2
start0 <- (1 - width)/2
time4 <- Sys.time()

newimw <- round(imw*width)
startpix <- round(imw*start0)
uvreduced2 <- imcrop(gruvred, 1, startpix, imh, newimw)
uvreduced <- filter(uvreduced2, flt, method="convolution",
                    sides=2, circular=TRUE)/length(flt)
test1uv <- thresholding(uvreduced, mode="fixed", thresh*255)
time5 <- Sys.time()

test3uv <- bwlabel2(test1uv)
num <- max(test3uv)
time6 <- Sys.time()

npixels <- matrix(0, 1, num)
rbar <- matrix(0, 1, num)
cbar <- matrix(0, 1, num)
for (j in 1:num) {
  temp <- which(test3uv == j)/imh
  c_ <- ceiling(temp)
  r_ <- round((temp + 1 - c_)*imh)
  npixels[j] <- length(c_)
  rbar[j] <- sum(r_)/npixels[j]
  cbar[j] <- sum(c_)/npixels[j]
}
skiplog <- matrix(0, 1, num)
for (j in 1:num) if (npixels[j] > 40) skiplog[j] <- 1
num2 <- sum(skiplog)
time7 <- Sys.time()

offset1 <- 0
cbar2 <- matrix(0, 1, num2)
rbar2 <- matrix(0, 1, num2)
for (j in 1:num) {
  if (skiplog[j]) {
    rbar2[j-offset1] <- rbar[j]
    cbar2[j-offset1] <- cbar[j]
  } else {
    offset1 <- offset1 + 1
  }
}
cbar2 <- cbar2 + startpix - 1

zz <- file(file.path(outdir, "blobs.raw"), "wb")
writeBin(as.integer(as.vector(t(test1uv*255))), zz, size=1)
close(zz)
time8 <- Sys.time()

zz <- file(file.path(outdir, "blobdata.txt"), "wt")
write(c(imh, newimw, num2, thresh), zz)
close(zz)
time9 <- Sys.time()

zz <- file(file.path(outdir, "pixels.txt"), "wt")
outputdata <- cbind(t(cbar2), t(rbar2))
write.table(outputdata, zz, col.names=FALSE, row.names=FALSE)
close(zz)
time10 <- Sys.time()

deltat <- (time10 - times)
cat(sprintf('Processing time is %g\n', deltat))
cat(sprintf('Run completed successfully\n'))
# END