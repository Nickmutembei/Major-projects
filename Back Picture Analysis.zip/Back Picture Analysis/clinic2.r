# clinic2.r
# Rotate/tilt, clinical analysis, PDF report generation.

rm(list=ls())
times <- Sys.time()
graphics.off()

source("setup_helpers.r")

mycol <- load_mycol("mycol.Rdata")

# ---------- local helpers ----------
meshplot <- function(a) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/60))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  persp(seq(1, ncol(aplot)), seq(1, nrow(aplot)),
        fliplr(t(aplot)), theta=0, phi=40, expand=0.5,
        asp=1, axes=FALSE, box=FALSE)
}

mycontourplot <- function(a, col1=mycol, xpixel=1, ypixel=1) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/120))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  aplot2 <- ifelse(aplot > 80, 80, aplot)
  xplot <- seq(1, ncol(aplot)) * xpixel * fact
  yplot <- seq(1, nrow(aplot)) * ypixel * fact
  maxaplot <- round(max(aplot, na.rm=TRUE)/10)*10
  image(xplot, yplot, fliplr(t(aplot2)), asp=1,
        zlim=c(-80,80), xlab="", ylab="", axes=FALSE, col=col1)
  contour(xplot, yplot, fliplr(t(aplot)),
          levels=seq(-60, maxaplot, by=5),
          asp=1, add=TRUE, axes=FALSE)
}

bamplot <- function(a, col1=mycol, limit=c(0,50)) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/120))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  filled.contour(seq(1, ncol(aplot))*fact, seq(1, nrow(aplot))*fact,
                 fliplr(t(aplot)), asp=1, zlim=limit,
                 xlab="", ylab="", axes=FALSE, col=col1)
}

myimage <- function(a, xpixel=1, ypixel=1) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/120))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  image(seq(1, ncol(aplot))*xpixel*fact, seq(1, nrow(aplot))*ypixel*fact,
        fliplr(t(aplot)), asp=1, xlab="", ylab="")
}

mypoly <- function(p, myx, myy) {
  yy <- p[1]+p[2]*myx+p[3]*myx^2+p[4]*myx^3+p[5]*myx^4+p[6]*myx^5
  sum((yy-myy)^2)
}

polyval <- function(p, x) {
  nc <- length(p); p <- fliplr(p)
  y <- seq(1, length(x))*0
  if (length(p) > 0) y[] <- p[1]
  for (ii in 2:nc) y <- x*y + p[ii]
  y
}

# ---------- load data ----------
load("surfdata.Rdata")

temp <- read.table("pixels.txt")
nblobs <- dim(temp)[1]
o <- order(temp$V2)
spine <- cbind(temp$V1[o], temp$V2[o])
yspine <- spine[1:(nblobs-2), ]
psisl <- spine[(nblobs-1), ]
psisr <- spine[nblobs, ]
if (psisr[1] < psisl[1]) {
  temp2 <- psisl; psisl <- psisr; psisr <- temp2
}
dvlx <- round(psisl[1]/fact)
dvly <- round(psisl[2]/fact)
dvrx <- round(psisr[1]/fact)
dvry <- round(psisr[2]/fact)
vpx  <- round(yspine[1,1]/fact)
vpy  <- round(yspine[1,2]/fact)
sacx <- round((dvlx+dvrx)/2)
sacy <- round((dvly+dvry)/2)
yspinepix <- round(yspine/fact)

ggrid <- meshgrid(x1, y1)
x1g <- ggrid[[1]]
y1g <- ggrid[[2]]

nh0 <- h3

# ---- Step 1: mm coordinates ----
dvl <- c(dvlx*deltapix, dvly*deltapix, nh0[dvly,dvlx])
dvr <- c(dvrx*deltapix, dvry*deltapix, nh0[dvry,dvrx])
vp  <- c(vpx*deltapix,  vpy*deltapix,  nh0[vpy,vpx])
sac <- c((dvl[1]+dvr[1])/2, (dvl[2]+dvr[2])/2, nh0[sacy,sacx])

numspine <- nblobs - 2
sp1 <- matrix(0, numspine, 3)
for (i in 1:numspine) {
  sp1[i,] <- c(x1[yspinepix[i,1]], y1[yspinepix[i,2]],
               nh0[yspinepix[i,2], yspinepix[i,1]])
}

# ---- Step 2: translate to dvl ----
x2 <- x1g - dvl[1]; y2 <- y1g - dvl[2]; nh2 <- nh0 - dvl[3]
dvl2 <- c(x2[dvly,dvlx], y2[dvly,dvlx], nh2[dvly,dvlx])
dvr2 <- c(x2[dvry,dvrx], y2[dvry,dvrx], nh2[dvry,dvrx])
vp2  <- c(x2[vpy,vpx],   y2[vpy,vpx],   nh2[vpy,vpx])
sac2 <- c(x2[sacy,sacx], y2[sacy,sacx], nh2[sacy,sacx])
sp2 <- matrix(0, numspine, 3)
for (i in 1:numspine) {
  sp2[i,] <- c(x2[yspinepix[i,2], yspinepix[i,1]],
               y2[yspinepix[i,2], yspinepix[i,1]],
               nh2[yspinepix[i,2], yspinepix[i,1]])
}

# ---- Step 3: rotate about y-axis ----
s3 <- dvr2[3]/sqrt(dvr2[1]^2 + dvr2[3]^2)
c3 <- dvr2[1]/sqrt(dvr2[1]^2 + dvr2[3]^2)
rot <- atan(s3/c3)*360/(2*pi)
x3 <- c3*x2 + s3*nh2
y3 <- y2
nh3 <- -s3*x2 + c3*nh2
dvl3 <- c(x3[dvly,dvlx], y3[dvly,dvlx], nh3[dvly,dvlx])
dvr3 <- c(x3[dvry,dvrx], y3[dvry,dvrx], nh3[dvry,dvrx])
vp3  <- c(x3[vpy,vpx],   y3[vpy,vpx],   nh3[vpy,vpx])
sac3 <- c(x3[sacy,sacx], y3[sacy,sacx], nh3[sacy,sacx])
sp3 <- matrix(0, numspine, 3)
for (i in 1:numspine) {
  sp3[i,] <- c(x3[yspinepix[i,2], yspinepix[i,1]],
               y3[yspinepix[i,2], yspinepix[i,1]],
               nh3[yspinepix[i,2], yspinepix[i,1]])
}

# ---- Step 4: rotate about z-axis ----
s4 <- dvr2[2]/sqrt(dvr2[1]^2 + dvr2[2]^2)
c4 <- dvr2[1]/sqrt(dvr2[1]^2 + dvr2[2]^2)
x4 <- x3*c4 + y3*s4
y4 <- -x3*s4 + y3*c4
nh4 <- nh3
dvl4 <- c(x4[dvly,dvlx], y4[dvly,dvlx], nh4[dvly,dvlx])
dvr4 <- c(x4[dvry,dvrx], y4[dvry,dvrx], nh4[dvry,dvrx])
vp4  <- c(x4[vpy,vpx],   y4[vpy,vpx],   nh4[vpy,vpx])
sac4 <- c(x4[sacy,sacx], y4[sacy,sacx], nh4[sacy,sacx])
sp4 <- matrix(0, numspine, 3)
for (i in 1:numspine) {
  sp4[i,] <- c(x4[yspinepix[i,2], yspinepix[i,1]],
               y4[yspinepix[i,2], yspinepix[i,1]],
               nh4[yspinepix[i,2], yspinepix[i,1]])
}

# ---- Step 5: translate to sacrum ----
x5 <- x4; y5 <- y4; nh5 <- nh4 - sac4[3]
dvl5 <- c(x5[dvly,dvlx], y5[dvly,dvlx], nh5[dvly,dvlx])
dvr5 <- c(x5[dvry,dvrx], y5[dvry,dvrx], nh5[dvry,dvrx])
vp5  <- c(x5[vpy,vpx],   y5[vpy,vpx],   nh5[vpy,vpx])
sac5 <- c(x5[sacy,sacx], y5[sacy,sacx], nh5[sacy,sacx])
sp5 <- matrix(0, numspine, 3)
for (i in 1:numspine) {
  sp5[i,] <- c(x5[yspinepix[i,2], yspinepix[i,1]],
               y5[yspinepix[i,2], yspinepix[i,1]],
               nh5[yspinepix[i,2], yspinepix[i,1]])
}

# ---- Step 6: tilt about x-axis ----
s6 <- -vp5[3]/sqrt(vp5[2]^2 + vp5[3]^2)
c6 <- -vp5[2]/sqrt(vp5[2]^2 + vp5[3]^2)
tilt <- atan(s6/c6)*360/(2*pi)
x6 <- x5
y6 <- y5*c6 + nh5*s6
nh6 <- -y5*s6 + nh5*c6
dvl6 <- c(x6[dvly,dvlx], y6[dvly,dvlx], nh6[dvly,dvlx])
dvr6 <- c(x6[dvry,dvrx], y6[dvry,dvrx], nh6[dvry,dvrx])
vp6  <- c(x6[vpy,vpx],   y6[vpy,vpx],   nh6[vpy,vpx])
sac6 <- c(x6[sacy,sacx], y6[sacy,sacx], nh6[sacy,sacx])
sp6 <- matrix(0, numspine, 3)
for (i in 1:numspine) {
  sp6[i,] <- c(x6[yspinepix[i,2], yspinepix[i,1]],
               y6[yspinepix[i,2], yspinepix[i,1]],
               nh6[yspinepix[i,2], yspinepix[i,1]])
}

# ---- Step 7: rotate back about z ----
s7 <- -s4; c7 <- c4
x7 <- x6*c7 + y6*s7
y7 <- -x6*s7 + y6*c7
nh7 <- nh6
dvl7 <- c(x7[dvly,dvlx], y7[dvly,dvlx], nh7[dvly,dvlx])
dvr7 <- c(x7[dvry,dvrx], y7[dvry,dvrx], nh7[dvry,dvrx])
vp7  <- c(x7[vpy,vpx],   y7[vpy,vpx],   nh7[vpy,vpx])
sac7 <- c(x7[sacy,sacx], y7[sacy,sacx], nh7[sacy,sacx])
sp7 <- matrix(0, numspine, 3)
for (i in 1:numspine) {
  sp7[i,] <- c(x7[yspinepix[i,2], yspinepix[i,1]],
               y7[yspinepix[i,2], yspinepix[i,1]],
               nh7[yspinepix[i,2], yspinepix[i,1]])
}

# ---- Step 8: shift origin to VP ----
x8 <- x7 - vp7[1]; y8 <- y7 - vp7[2]; nh8 <- nh7 - vp7[3]
dvl8 <- c(x8[dvly,dvlx], y8[dvly,dvlx], nh8[dvly,dvlx])
dvr8 <- c(x8[dvry,dvrx], y8[dvry,dvrx], nh8[dvry,dvrx])
vp8  <- c(x8[vpy,vpx],   y8[vpy,vpx],   nh8[vpy,vpx])
sac8 <- c(x8[sacy,sacx], y8[sacy,sacx], nh8[sacy,sacx])
sp8 <- matrix(0, numspine, 3)
for (i in 1:numspine) {
  sp8[i,] <- c(x8[yspinepix[i,2], yspinepix[i,1]],
               y8[yspinepix[i,2], yspinepix[i,1]],
               nh8[yspinepix[i,2], yspinepix[i,1]])
}

# ---- Step 9: new grid ----
deltax <- deltapix/cos(rot*2*pi/360)
deltay <- deltapix/cos(tilt*2*pi/360)
xng <- (1:sizew)*deltax
yng <- (1:sizeh)*deltay
xng <- xng - xng[vpx]
yng <- yng - yng[vpy]
nggrid <- meshgrid(xng, yng)
xng2 <- nggrid[[1]]
yng2 <- nggrid[[2]]
nh9 <- nh8
x9 <- xng2
y9 <- yng2
xmin <- min(x9)
ymin <- min(y9)
vp9rownum  <- vpy
vp9colnum  <- vpx
sac9rownum <- sacy
sac9colnum <- sacx
dvl9 <- c(x9[dvly,dvlx], y9[dvly,dvlx], nh9[dvly,dvlx])
dvr9 <- c(x9[dvry,dvrx], y9[dvry,dvrx], nh9[dvry,dvrx])
vp9  <- c(x9[vp9rownum,vp9colnum], y9[vp9rownum,vp9colnum], nh9[vp9rownum,vp9colnum])
sac9 <- c(x9[sac9rownum,sac9colnum], y9[sac9rownum,sac9colnum], nh9[sac9rownum,sac9colnum])
nh9d <- nh9 * maskred
sp9 <- matrix(0, numspine + 1, 3)
for (i in 1:numspine) {
  sp9[i,] <- c(x9[yspinepix[i,2], yspinepix[i,1]],
               y9[yspinepix[i,2], yspinepix[i,1]],
               nh9[yspinepix[i,2], yspinepix[i,1]])
}
sp9[numspine+1, ] <- sac9

# ---------------- PDF plot ----------------
pdffile <- "results.pdf"
pdf(pdffile, width=7.5, height=7.5, bg="white", onefile=TRUE, family="Times")
layout(matrix(c(1,1,1,1,1,1,1,2,2,2,2,2,2,2,3,3,3,3,3,4,4,4,4,
                5,5,5,5,5), 2, 14, byrow=TRUE))

# HEIGHT MAP
par(mai=c(0,0,0.15,0))
meshplot(nh9d)
title("Height map")

# CONTOUR PLOT
par(mai=c(0.4,0.3,0.3,0.16))
mycontourplot(nh9d)
title("Contour plot")
for (j in 1:(nblobs-2)) {
  points(yspinepix[j,1], sizeh+1-yspinepix[j,2], pch=19, col="blue")
}
points(dvrx, sizeh-dvry, pch=19, col="blue")
points(dvlx, sizeh-dvly, pch=19, col="blue")

# max hump markers
colliml1 <- round(vp9colnum - 0.3*(sac9rownum - vp9rownum))
if (colliml1 < 1) colliml1 <- 1
colliml2 <- vp9colnum
rowliml1 <- round(vp9rownum + 0.15*(sac9rownum - vp9rownum))
rowliml2 <- round(vp9rownum + 0.55*(sac9rownum - vp9rownum))
left <- nh9d[rowliml1:rowliml2, colliml1:colliml2]
maxleft <- max(left, na.rm=TRUE)
maxleftloc <- which.max(left)
nrowleft <- nrow(left)
leftremain <- maxleftloc/nrowleft - floor(maxleftloc/nrowleft)
maxleftrowloc <- nrowleft*leftremain
maxleftcolloc <- floor(maxleftloc/nrowleft)+1
if (leftremain == 0) {
  maxleftrowloc <- nrowleft
  maxleftcolloc <- floor(maxleftloc/nrowleft)
}
maxleftrowloc <- maxleftrowloc + rowliml1 - 1
maxleftcolloc <- maxleftcolloc + colliml1 - 1

collimr1 <- round(vp9colnum + 0.3*(sac9rownum - vp9rownum))
if (collimr1 > ncol(nh9d)) collimr1 <- ncol(nh9d)
collimr2 <- vp9colnum
rowlimr1 <- round(vp9rownum + 0.15*(sac9rownum - vp9rownum))
rowlimr2 <- round(vp9rownum + 0.55*(sac9rownum - vp9rownum))
right <- nh9d[rowlimr1:rowlimr2, collimr2:collimr1]
maxright <- max(right, na.rm=TRUE)
maxrightloc <- which.max(right)
nrowright <- nrow(right)
rightremain <- maxrightloc/nrowright - floor(maxrightloc/nrowright)
maxrightrowloc <- nrowright*rightremain
maxrightcolloc <- floor(maxrightloc/nrowright)+1
if (rightremain == 0) {
  maxrightrowloc <- nrowright
  maxrightcolloc <- floor(maxrightloc/nrowright)
}
maxrightrowloc <- maxrightrowloc + rowlimr1 - 1
maxrightcolloc <- maxrightcolloc + collimr2 - 1
points(maxleftcolloc, sizeh-maxleftrowloc, pch=17, col="blue")
points(maxrightcolloc, sizeh-maxrightrowloc, pch=17, col="blue")
scapdiffheight <- round(-(maxrightrowloc - maxleftrowloc)*deltay)

# spine polynomial fit
x0spine <- c(sp9[1,1], sp9[,1], sp9[numspine+1,1])
y0spine <- c((sp9[1,2]-40), sp9[,2], (sp9[numspine+1,2]+40))
backlength <- sac9[2]
x0spine <- x0spine/backlength
y0spine <- -y0spine/backlength
xmin <- xmin/backlength
yng <- -yng/backlength
xng <- xng/backlength
deltaxnorm <- deltax/backlength
pc <- c(1,1,1,1,1,1)
non <- nlm(mypoly, pc, gradtol=1e-8, myx=y0spine, myy=x0spine)
ps <- non$estimate
x1spine <- polyval(ps, yng)
x1sppix <- round((x1spine - xmin)/deltaxnorm + 1)
z1spine <- seq(1, sizeh)*0
for (i in 1:sizeh) z1spine[i] <- nh9d[i, x1sppix[i]]

maxleftoff <- round((x1sppix[maxleftrowloc] - maxleftcolloc)*deltax)
maxrightoff <- round((maxrightcolloc - x1sppix[maxrightrowloc])*deltax)

# TRANSVERSE PLOTS
numlev <- 19
lev <- matrix(0, 1, numlev)
lev[1] <- vp9rownum
lev[numlev] <- sac9rownum
deltalev <- (sac9rownum - vp9rownum)/(numlev-1)
for (i in 2:(numlev-1)) lev[i] <- round(vp9rownum + (i-1)*deltalev)

paramed <- backlength/10
plotwidth <- round(paramed/deltax)
section <- matrix(0, numlev, sizew)
spsectpix <- seq(1, numlev)*0
for (i in 1:numlev) {
  section[i, ] <- nh9d[lev[i], ]
  spsectpix[i] <- x1sppix[lev[i]]
}

const <- c(0.7, 1.7, 2.7, 2.7, 2.7, 2.7, 2.7, 2.7, 2.7, 2.5, 2.25,
           2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0)
minw <- spsectpix - round(plotwidth*const)
maxw <- spsectpix + round(plotwidth*const)
for (i in 1:length(minw)) {
  if (minw[i] < 2) minw[i] <- 2
  if (maxw[i] > (sizew-1)) maxw[i] <- sizew-1
}
for (i in 1:numlev) {
  for (j in 1:minw[i]-1) section[i,j] <- NaN
  for (j in (maxw[i]+1):sizew) section[i,j] <- NaN
}
section2 <- section/backlength
vertsp <- seq(1, numlev)*0
section3 <- matrix(0, numlev, sizew)
lev2 <- seq(1, numlev)*0
for (i in 1:numlev) {
  vertsp[i] <- section2[i, spsectpix[i]]
  lev2[i] <- (lev[i]-lev[1])/(lev[numlev]-lev[1])
  section3[i, ] <- 1*(section2[i, ]-vertsp[i]) - lev2[i]
}
sections3 <- t(section3)
x10 <- t(x9[1:19, ]/backlength)
par(mai=c(0.2,0.15,0.15,0.08))
plot(x10, sections3, type="l", xlab="", ylab="", main="Transverse",
     xlim=c(-0.4,0.4), ylim=c(-1.2,0.05), axes=FALSE)
paramin <- round(spsectpix - plotwidth)
paramax <- round(spsectpix + plotwidth)
for (i in 2:numlev) {
  points(x10[paramin[i],1], sections3[paramin[i],i], col="red")
  points(x10[spsectpix[i],1], sections3[spsectpix[i],i], col="blue")
  points(x10[paramax[i],1], sections3[paramax[i],i], col="green")
}
points(x10[vp9colnum,1], sections3[vp9colnum,1], pch=19, col="blue")
points(x10[sac9colnum,1], sections3[sac9colnum,numlev], pch=23, col="magenta")

ang <- matrix(0, 1, numlev)
for (i in 2:numlev) {
  ang[i] <- 57.2958*atan((section[i,paramax[i]] - section[i,paramin[i]])/(2*plotwidth*deltax))
  if (is.na(ang[i])) {
    ang[i] <- 57.2958*atan((section[i,paramax[i]-5] - section[i,paramin[i]+5])/((2*plotwidth-10)*deltax))
  }
}
for (i in 2:numlev) {
  angp <- round(ang[i])
  textn <- substitute(paste(angp,degree), list(angp=angp))
  text(0.35, -lev2[i]+0.01, textn, cex=1.0, pos=1, offset=0.05)
}
rotp <- round(rot)
text1 <- substitute(paste("Rotation = ", rotp, degree), list(rotp=rotp))
text3 <- sprintf("Backlength = %5.0f mm", backlength)
text(0, -1.07, text1, cex=1.0)
text(0, -1.13, text3, cex=1.0)
text(0.3, 0, "Skin angle", cex=1.0)
text(-0.25, -1.22, "Code7701", cex=1.0)

maxskinang <- round(max(abs(ang), na.rm=TRUE))
maxskin <- round(max(ang, na.rm=TRUE))
minskin <- round(min(ang, na.rm=TRUE))
if (abs(minskin) > abs(maxskin)) maxskinang <- -maxskinang

# CORONAL PLOT
k <- c(0, 0.4, 1.8, 2.2, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5,
       2.5, 2.5, 2.5, 2.5, 2.5, 1.0, 0.0)
deltab <- 1/(numlev-1)
len <- matrix(0, 1, numlev)
p <- matrix(0, 1, numlev)
p[1] <- 0.03*backlength
for (i in 2:numlev) {
  len[i] <- deltab*(i-1)
  p[i] <- 0.03*(1 + 3*len[i])*backlength
}
shiftx <- p*sin(k*ang/57.2958)/backlength
shiftx[numlev] <- 0
xspinproc <- seq(1:numlev)*0
xshift <- seq(1:numlev)*0
yspinproc <- seq(1:numlev)*0
for (i in 1:numlev) {
  xspinproc[i] <- x1spine[lev[i]]
  xshift[i] <- xspinproc[i] + shiftx[i]
  yspinproc[i] <- yng[lev[i]]
}
xvert <- c(xshift[1], xshift, xshift[numlev])
yvert <- c(yspinproc[1]+0.08, yspinproc, yspinproc[numlev]-0.08)
non2 <- nlm(mypoly, pc, gradtol=1e-8, myx=yvert, myy=xvert)
pv <- non2$estimate
newspine <- polyval(pv, yng)
plot(xspinproc, yspinproc, type="l", main="Coronal", col="blue",
     lwd=2, xlim=c(-0.4,0.4), ylim=c(-1.2,0.05), xlab="", ylab="", axes=FALSE)
imb <- round(sac9[1])
text4 <- paste("Imbalance = ", imb, " mm")
text(0, -1.08, text4, cex=1.0)

yplus <- round((lev[19]-lev[1]+1)*0.06)
toplev <- max(lev[1]-yplus, 1)
botlev <- min(lev[19]+yplus, length(yng))
lines(newspine[toplev:botlev], yng[toplev:botlev], lty=2, lwd=2)
lines(c(0,0), c(0.06,-1.06), col="blue")
lines(xspinproc + paramed/backlength, yspinproc, col="green", lwd=2)
lines(xspinproc - paramed/backlength, yspinproc, col="red", lwd=2)
points(dvl8[1]/backlength, -dvl8[2]/backlength, pch=19, col="blue")
points(dvr8[1]/backlength, -dvr8[2]/backlength, pch=19, col="blue")
points(sac9[1]/backlength, -sac9[2]/backlength, pch=23, col="magenta")
points(vp9[1]/backlength,  -vp9[2]/backlength,  pch=19, col="blue")

coeffv <- c(2*pv[3], 6*pv[4], 12*pv[5], 20*pv[6])
rv <- polyroot(coeffv)
rv <- fliplr(sort(rv))
xcalcv <- Re(polyval(pv, rv))
slopev <- Re(pv[2]+2*pv[3]*rv+3*pv[4]*rv^2+4*pv[5]*rv^3+5*pv[6]*rv^4)
cobbv <- 0.9*(-atan(slopev)*57.2957795)
anglev <- -atan(slopev)
rv2 <- c(1,1,1)
for (ii in 1:3) {
  if (Re(rv[ii]) > 0.06) rv2[ii] <- 0
  if (Re(rv[ii]) < -1.06) rv2[ii] <- 0
}
if ((Re(rv[1])-Re(rv[2])) < 0.00001) rv2[1] <- 0
if ((Re(rv[2])-Re(rv[3])) < 0.00001) rv2[3] <- 0
nptv <- sum(rv2)
rvp <- round(Re(rv), 2)
xgradplot <- c(-0.2,-0.1,0,0.1,0.2)
for (ii in 1:3) {
  if (rv2[ii] > 0) {
    ygradv <- -xgradplot*slopev[ii] + Re(rv[ii]) + slopev[ii]*xcalcv[ii]
    lines(xgradplot, ygradv, lty=3, lwd=2)
    cobbvp <- round(cobbv[ii], 1)
    text1 <- substitute(paste(cobbvp, degree), list(cobbvp=cobbvp))
    text(0.3, Re(rv[ii]), text1, cex=1.0)
  }
}
upcobbv <- round((cobbv[2]-cobbv[1]), 6)
textup <- "R"
if (upcobbv > 0) textup <- "L"
lowcobbv <- round((cobbv[3]-cobbv[2]), 6)
textlow <- "R"
if (lowcobbv > 0) textlow <- "L"
upcobbv2 <- round(abs(upcobbv))
lowcobbv2 <- round(abs(lowcobbv))
if (nptv == 3) {
  txt5 <- substitute(paste("Lateral asymmetry = ", upcobbv2, degree, textup,
                           " and ", lowcobbv2, degree, textlow),
                     list(upcobbv2=upcobbv2, textup=textup,
                          lowcobbv2=lowcobbv2, textlow=textlow))
  text(0, -1.14, txt5, cex=1.0)
}
if (nptv == 2) {
  if (rv2[1]) txt5 <- substitute(paste("Lateral asymmetry = ", upcobbv2, degree, textup),
                                 list(upcobbv2=upcobbv2, textup=textup))
  if (rv2[3]) txt5 <- substitute(paste("Lateral asymmetry =  ", lowcobbv2, degree, textlow),
                                 list(lowcobbv2=lowcobbv2, textlow=textlow))
  text(0, -1.14, txt5, cex=1.0)
}

# Bilateral asymmetry
bam0 <- matrix(0, sizeh, sizew)
bam  <- matrix(NaN, sizeh, sizew)
nw <- 3*plotwidth
if (nw > min(x1sppix)) nw <- min(x1sppix)-1
if (nw > (sizew-max(x1sppix))) nw <- (sizew-max(x1sppix))-1
for (i in lev[1]:lev[numlev]) {
  n <- x1sppix[i]
  test1 <- nh9d[i, (n+1):(n+nw)]
  test2 <- nh9d[i, (n-nw):(n-1)]
  test3 <- fliplr(test2)
  delt <- test1 - test3
  bam0[i, (n+1):(n+nw)] <- delt
  delt2 <- fliplr(delt)
  bam0[i, (n-nw):(n-1)] <- delt2
}
tftemp <- is.na(bam0)
const2 <- matrix(0, 1, sizeh)
const2[lev[4]:lev[9]] <- 2.0
const2[lev[13]:lev[numlev]] <- 1.5
for (i in (lev[9]+1):(lev[13]-1)) {
  const2[i] <- 2.0 - 0.5*(i-lev[9])/(lev[13]-lev[9])
}
minw2 <- x1sppix - round(plotwidth*const2)
maxw2 <- x1sppix + round(plotwidth*const2)
for (i in 1:sizeh) {
  for (j in minw2[i]:(x1sppix[i]-1)) {
    if (!is.na(tftemp[i,j]) && !tftemp[i,j] && bam0[i,j] < 0) bam[i,j] <- -bam0[i,j]
  }
  for (j in (x1sppix[i]+1):maxw2[i]) {
    if (!is.na(tftemp[i,j]) && !tftemp[i,j] && bam0[i,j] > 0) bam[i,j] <- bam0[i,j]
  }
}
area <- seq(1:numlev)*0
for (i in 2:19) {
  area[i] <- sum(bam0[lev[i], minw2[lev[i]]:x1sppix[lev[i]]], na.rm=TRUE)*deltax
}
slice <- (lev[19]-lev[1]+1)*deltay/18
volasym <- area * slice/(2*backlength*backlength)
volx <- cbind(xspinproc, xspinproc + volasym)
voly <- cbind(yspinproc, yspinproc)
for (ii in 4:19) lines(volx[ii,], voly[ii,])
volr <- sum(volasym[volasym > 0], na.rm=TRUE)*50
voll <- abs(sum(volasym[volasym < 0], na.rm=TRUE)*50)
volr2 <- round(volr); voll2 <- round(voll)
txt7 <- sprintf("Volumetric asymmetry = %4.0f %s   %4.0f %s", voll, "L", volr, "R")
text(0, -1.19, txt7, cex=1.0)

# SAGITTAL PLOTS
off <- c(-0.24*backlength, 0, 0.24*backlength)
st <- sin(-tilt*2*pi/360); ct <- cos(-tilt*2*pi/360)
zoldvp <- seq(1, length(x1sppix))*0
for (ii in 1:length(x1sppix)) zoldvp[ii] <- nh9d[ii, x1sppix[ii]]
yold <- yng*backlength
znewc <- zoldvp*ct + yold*st
ynewc <- -zoldvp*st + yold*ct
plot(znewc[vp9rownum:sac9rownum], ynewc[vp9rownum:sac9rownum],
     type="l", lwd=2, col="blue",
     xlim=c(-0.24*backlength, 0.36*backlength),
     ylim=c(-1.2*backlength, 0.05*backlength), asp=1,
     xlab="", ylab="", axes=FALSE)
title("Sagittal")
zoldparamin <- seq(1, length(x1sppix))*0
for (ii in 1:length(x1sppix)) zoldparamin[ii] <- nh9d[ii, x1sppix[ii]-plotwidth]
znewpl <- zoldparamin*ct + yold*st
ynewpl <- -zoldparamin*st + yold*ct
lines(znewpl[vp9rownum:sac9rownum]+off[1], ynewpl[vp9rownum:sac9rownum],
      lwd=2, col="red")
zoldparamax <- seq(1, length(x1sppix))*0
for (ii in 1:length(x1sppix)) zoldparamax[ii] <- nh9d[ii, x1sppix[ii]+plotwidth]
znewpr <- zoldparamax*ct + yold*st
ynewpr <- -zoldparamax*st + yold*ct
lines(znewpr[vp9rownum:sac9rownum]+off[3], ynewpr[vp9rownum:sac9rownum],
      lwd=2, col="green")
zvc <- zoldvp*0
znewvc <- zvc*ct + yold*st
ynewvc <- -zvc*st + yold*ct
lines(znewvc[(vp9rownum-5):(sac9rownum+5)]+off[1],
      ynewvc[(vp9rownum-5):(sac9rownum+5)], col="red")
lines(znewvc[(vp9rownum-5):(sac9rownum+5)]+off[2],
      ynewvc[(vp9rownum-5):(sac9rownum+5)], col="blue")
lines(znewvc[(vp9rownum-5):(sac9rownum+5)]+off[3],
      ynewvc[(vp9rownum-5):(sac9rownum+5)], col="green")

sagittalsect <- cbind(zoldparamin[vp9rownum:sac9rownum],
                      zoldvp[vp9rownum:sac9rownum],
                      zoldparamax[vp9rownum:sac9rownum])
pos0 <- round(nrow(sagittalsect)/10)
saglen <- round(2*nrow(sagittalsect)/3)
mx <- apply(sagittalsect[pos0:saglen, ], 2, max, na.rm=TRUE)
rmax <- apply(sagittalsect[pos0:saglen, ], 2, which.max)
pos1 <- max(rmax)
pos2 <- sac9rownum - vp9rownum + 1
mn <- apply(sagittalsect[pos1:pos2, ], 2, min, na.rm=TRUE)
rmin <- apply(sagittalsect[pos1:pos2, ], 2, which.min)
rmax <- rmax + vp9rownum + pos0 - 2
rmin <- rmin + vp9rownum + pos1 - 2
for (ii in 1:3) {
  zh1 <- c(0, mx[ii]); yh1 <- c(yold[rmax[ii]], yold[rmax[ii]])
  zmaxh2 <- zh1*ct + yh1*st + off[ii]
  ymaxh2 <- -zh1*st + yh1*ct
  lines(zmaxh2, ymaxh2)
  zh1 <- c(0, mn[ii]); yh1 <- c(yold[rmin[ii]], yold[rmin[ii]])
  zminh2 <- zh1*ct + yh1*st + off[ii]
  yminh2 <- -zh1*st + yh1*ct
  lines(zminh2, yminh2)
  zpos <- zmaxh2[2]+14; ypos <- ymaxh2[2]
  if (max(mx)/backlength > 0.165) { zpos <- zmaxh2[2]-25; ypos <- ymaxh2[2]+12 }
  text(zpos, ypos, formatC(mx[ii], digits=0, format="f"), cex=1.0)
  text(zminh2[2]-20, yminh2[2], formatC(mn[ii], digits=0, format="f"), cex=1.0)
}
tiltp <- round(tilt)
text2 <- substitute(paste("Extension = ", tiltp, degree), list(tiltp=tiltp))
if (tilt > 0) text2 <- substitute(paste("Flexion = ", tiltp, degree), list(tiltp=tiltp))
text(0.12*backlength, -1.05*backlength, text2, cex=1.0)
text(0.12*backlength, -1.10*backlength,
     "Max kyphosis and lordosis on plot in mm", cex=1.0)
maxkyph <- round(max(mx))
maxlord <- round(abs(min(mn)))

# kyphosis/lordosis via curve fit
ykyph1 <- yold[vp9rownum:sac9rownum]/backlength
zkyph1 <- zoldvp[vp9rownum:sac9rownum]/backlength
pc2 <- c(1,1,1,1,1,1)
non2 <- nlm(mypoly, pc2, gradtol=1e-8, myx=ykyph1, myy=zkyph1)
ps2 <- non2$estimate
coeffvk <- c(2*ps2[3], 6*ps2[4], 12*ps2[5], 20*ps2[6])
rvk <- polyroot(coeffvk)
rvk <- fliplr(sort(rvk))
xcalcvk <- Re(polyval(ps2, rvk))
slopevk <- Re(ps2[2]+2*ps2[3]*rvk+3*ps2[4]*rvk^2+4*ps2[5]*rvk^3+5*ps2[6]*rvk^4)
rvkind <- c(1,1,1)
for (ii in 1:3) {
  if (Re(rvk[ii]) > 0) rvkind[ii] <- 0
  if (Re(rvk[ii]) < -1) rvkind[ii] <- 0
  if (abs(Im(rvk[ii])) > 0.000001) rvkind[ii] <- 0
}
slopevk2 <- slopevk*rvkind
locind <- which.max(slopevk2)
inflect <- round(Re(rvk[locind]), 2)
kyphprint <- (inflect < -0.05) & (inflect > -0.95)
midangle <- -atan(slopevk[locind])*57.2957795
myslope <- Re(ps2[2]+2*ps2[3]*ykyph1+3*ps2[4]*ykyph1^2+4*ps2[5]*ykyph1^3+5*ps2[6]*ykyph1^4)
blpix <- sac9rownum - vp9rownum + 1
topkyphrow <- round(0.05*blpix)
if (topkyphrow < 11) topkyphrow <- 11
topkyphslope <- sum(myslope[(topkyphrow-10):(topkyphrow+10)])/21
topkyphangle <- -atan(topkyphslope)*57.2957795
topkyphslope2 <- sum(myslope[1:21])/21
topkyphangle2 <- -atan(topkyphslope2)*57.2957795
botlordslope <- sum(myslope[(length(myslope)-20):(length(myslope))])/21
botlordangle <- -atan(botlordslope)*57.2957795
kyphangle <- round(midangle - topkyphangle, 4)
lordangle <- round(botlordangle - midangle, 4)
kyphangle2 <- round(midangle - topkyphangle2, 4)
kyphanglep <- round(abs(kyphangle))
lordanglep <- round(lordangle)
txtkl2 <- substitute(paste("Kyphosis = ", kyphanglep, degree,
                           " Lordosis = ", lordanglep, degree),
                     list(kyphanglep=kyphanglep, lordanglep=lordanglep))
if (kyphprint) text(0.12*backlength, -1.15*backlength, txtkl2, cex=1.0)
inflectrownum <- vp9rownum + round(-inflect*(sac9rownum - vp9rownum + 1))
if (kyphprint) {
  midx <- c(zoldvp[inflectrownum]-0.05*backlength,
            zoldvp[inflectrownum],
            zoldvp[inflectrownum]+0.05*backlength)
  midy <- c(yold[inflectrownum]-0.05*backlength*sin(midangle/57.2957795),
            yold[inflectrownum],
            yold[inflectrownum]+0.05*backlength*sin(midangle/57.2957795))
  midxnew <- midx*ct + midy*st
  midynew <- -midx*st + midy*ct
  lines(midxnew, midynew)
  midx2 <- c(zoldvp[vp9rownum+topkyphrow]-0.05*backlength,
             zoldvp[vp9rownum+topkyphrow],
             zoldvp[vp9rownum+topkyphrow]+0.05*backlength)
  midy2 <- c(yold[vp9rownum+topkyphrow]-0.05*backlength*sin(topkyphangle/57.2957795),
             yold[vp9rownum+topkyphrow],
             yold[vp9rownum+topkyphrow]+0.05*backlength*sin(topkyphangle/57.2957795))
  midxnew2 <- midx2*ct + midy2*st
  midynew2 <- -midx2*st + midy2*ct
  lines(midxnew2, midynew2)
  midx3 <- c(zoldvp[sac9rownum-10]-0.05*backlength,
             zoldvp[sac9rownum-10],
             zoldvp[sac9rownum-10]+0.05*backlength)
  midy3 <- c(yold[sac9rownum-10]-0.05*backlength*sin(botlordangle/57.2957795),
             yold[sac9rownum-10],
             yold[sac9rownum-10]+0.05*backlength*sin(botlordangle/57.2957795))
  midxnew3 <- midx3*ct + midy3*st
  midynew3 <- -midx3*st + midy3*ct
  lines(midxnew3, midynew3)
}
if (!kyphprint) {
  text(0.12*backlength, -1.20*backlength,
       "Kyphosis/lordosis angles - no results available", cex=1.0)
}
dev.off()
time32 <- Sys.time()

# ---------- BILATERAL ASYMMETRY PDFs ----------
swidth <- 2.7
if (round(nw/plotwidth, 1) < swidth) swidth <- round(nw/plotwidth, 1)
vpwidth <- 0.7
lbackwidth <- 2.0
const2 <- matrix(0, 1, sizeh)
const2[lev[1]] <- 0.3
const2[lev[3]:lev[9]] <- swidth
const2[lev[12]:lev[numlev]] <- 2.0
for (i in (lev[1]+1):(lev[3]-1)) {
  const2[i] <- vpwidth + (swidth-vpwidth)*(i-lev[1])/(lev[3]-lev[1])
}
for (i in (lev[9]+1):(lev[12]-1)) {
  const2[i] <- swidth - (swidth-lbackwidth)*(i-lev[9])/(lev[12]-lev[9])
}
minw2 <- x1sppix - round(plotwidth*const2)
maxw2 <- x1sppix + round(plotwidth*const2)
for (i in 1:sizeh) {
  for (j in minw2[i]:(x1sppix[i]-1)) {
    if (!is.na(tftemp[i,j]) && !tftemp[i,j] && bam0[i,j] < 0) bam[i,j] <- -bam0[i,j]
  }
  for (j in (x1sppix[i]+1):maxw2[i]) {
    if (!is.na(tftemp[i,j]) && !tftemp[i,j] && bam0[i,j] > 0) bam[i,j] <- bam0[i,j]
  }
}
time33 <- Sys.time()

a <- bam
nrows0 <- nrow(a); ncols0 <- ncol(a)
fact2 <- max(1, round(nrows0/120))
nrp.seq <- seq(1, nrows0, fact2)
ncp.seq <- seq(1, ncols0, fact2)
aplot <- a[nrp.seq, ncp.seq]
nrows <- nrow(aplot); ncols <- ncol(aplot)
xplot <- seq(1, ncols)*fact2
yplot <- seq(1, nrows)*fact2
zlim <- range(aplot, finite=FALSE, na.rm=TRUE)
minw2[1:(lev[1]-2)] <- NaN
minw2[(lev[numlev]+2):sizeh] <- NaN
maxw2[1:(lev[1]-2)] <- NaN
maxw2[(lev[numlev]+2):sizeh] <- NaN
leftline <- fliplr(minw2)
rightline <- fliplr(maxw2)
yup <- max(yplot) - lev[1] + fact2 + 1
ylow <- max(yplot) - lev[19] - fact2 - 1
yspread <- (yup-ylow)/2
xmid <- max(xplot)/2
xlow <- xmid - yspread
xup <- xmid + yspread
if (xlow < xplot[1]) xlow <- xplot[1]
if (xup > xplot[ncols]) xup <- xplot[ncols]

pdf("bamall.pdf", width=7.0, height=7.5, bg="white", onefile=TRUE, family="Times")
par(oma=c(0,0,0,1.5), mar=c(1,1,3,1))
filled.contour(xplot, yplot, fliplr(t(aplot)), frame.plot=FALSE,
               ylim=c(ylow,yup), xlim=c(xlow,xup), asp=1, xlab="", ylab="",
               levels=seq(0, zlim[2], zlim[2]/64), col=mycol,
               plot.title=title(main="Bilateral Asymmetry Map\nall differences"),
               key.title=title(main="mm"),
               plot.axes={lines(leftline, 1:sizeh, lwd=2)
                 lines(rightline, 1:sizeh, lwd=2)})
dev.off()

aplot2 <- ifelse(aplot < 10, NaN, aplot)
aplot2 <- ifelse(aplot > 30, 30, aplot2)
pdf("bamhigh.pdf", width=7.0, height=7.5, bg="white", onefile=TRUE, family="Times")
par(oma=c(0,0,0,1.5), mar=c(1,1,3,1))
filled.contour(xplot, yplot, fliplr(t(aplot2)), asp=1, frame.plot=FALSE,
               ylim=c(ylow,yup), xlim=c(xlow,xup), xlab="", ylab="",
               levels=seq(0, 30, 30/64), col=mycol,
               plot.title=title(main="Bilateral Asymmetry Map\ndifferences >10mm"),
               key.title=title(main="mm"),
               plot.axes={lines(leftline, 1:sizeh, lwd=2)
                 lines(rightline, 1:sizeh, lwd=2)})
dev.off()
time34 <- Sys.time()

# ---------- numeric output ----------
zz <- file("results.txt", "wt")
outputdata <- c(round(backlength), round(rot), round(tilt), imb, nptv, rv2, rvp,
                round(upcobbv), textup, round(lowcobbv), textlow,
                maxskin, minskin, maxkyph, maxlord,
                kyphanglep, lordanglep, inflect,
                scapdiffheight, maxleftoff, maxrightoff, voll2, volr2)
write(outputdata, zz)
close(zz)
time35 <- Sys.time()

deltat <- (time35 - times)
cat(sprintf('Processing time is %g\n', deltat))
cat(sprintf('Run completed successfully\n'))
# END