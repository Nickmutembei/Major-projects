# setup_helpers.r
# Cross-platform helper functions replacing rimage + compiled C code.
# Source this at the top of surfcolour.r, blob.r, clinic2.r, refcalvert.r

# ---- JPEG reading ----
read_jpeg_rgb <- function(path) {
  if (!requireNamespace("jpeg", quietly = TRUE))
    stop("Please run: install.packages('jpeg')")
  jpeg::readJPEG(path)
}
read_jpeg_green <- function(path) {
  img <- read_jpeg_rgb(path)
  if (length(dim(img)) == 3) img[,,2] else img
}

# ---- thresholding (replaces rimage::thresholding) ----
thresholding <- function(img, mode = "fixed", th = 0.5, ...) {
  img <- as.matrix(img)
  rng <- range(img, na.rm = TRUE)
  if (diff(rng) == 0) return(matrix(0, nrow(img), ncol(img)))
  norm <- (img - rng[1]) / diff(rng)
  if (mode == "fixed") {
    return(ifelse(norm > th, 1, 0))
  }
  # Otsu fallback
  brks <- seq(0, 1, length.out = 256)
  h <- hist(norm, breaks = brks, plot = FALSE)$counts
  p <- h / sum(h)
  omega <- cumsum(p)
  mu <- cumsum(p * (brks[-1] + brks[-length(brks)]) / 2)
  muT <- mu[length(mu)]
  sigmaB <- (muT * omega - mu)^2 / (omega * (1 - omega) + 1e-12)
  k <- which.max(sigmaB)
  return(ifelse(norm > brks[k], 1, 0))
}

# ---- 3x3 max filter (replaces rimage::maxImg dilation) ----
maxImg <- function(img) {
  img <- as.matrix(img)
  nr <- nrow(img); nc <- ncol(img)
  out <- img
  pad <- matrix(0, nr + 2, nc + 2)
  pad[2:(nr+1), 2:(nc+1)] <- img
  for (i in 1:nr) for (j in 1:nc) {
    out[i,j] <- max(pad[i:(i+2), j:(j+2)])
  }
  out
}

# ---- 8-connected component labelling (replaces .C("bwlabel2",...)) ----
bwlabel2 <- function(imgin) {
  m <- as.matrix(imgin) > 0
  nr <- nrow(m); nc <- ncol(m)
  labels <- matrix(0L, nr, nc)
  current <- 0L
  for (i in seq_len(nr)) {
    for (j in seq_len(nc)) {
      if (m[i,j] && labels[i,j] == 0L) {
        current <- current + 1L
        stack_i <- i; stack_j <- j
        while (length(stack_i)) {
          li <- length(stack_i)
          ci <- stack_i[li]; cj <- stack_j[li]
          stack_i <- stack_i[-li]; stack_j <- stack_j[-li]
          if (ci < 1 || ci > nr || cj < 1 || cj > nc) next
          if (!m[ci,cj] || labels[ci,cj] != 0L) next
          labels[ci,cj] <- current
          for (di in -1:1) for (dj in -1:1) {
            if (di == 0 && dj == 0) next
            stack_i <- c(stack_i, ci + di)
            stack_j <- c(stack_j, cj + dj)
          }
        }
      }
    }
  }
  return(labels)
}

# ---- excise (replaces .C("excise",...)) ----
# Removes connected components that touch the image border.
excise <- function(maskin) {
  m <- as.matrix(maskin) > 0
  nr <- nrow(m); nc <- ncol(m)
  visited <- matrix(FALSE, nr, nc)
  stack_i <- integer(); stack_j <- integer()
  # seed from all border pixels that are TRUE
  for (i in c(1, nr)) for (j in 1:nc) {
    if (m[i,j]) { stack_i <- c(stack_i, i); stack_j <- c(stack_j, j) }
  }
  for (j in c(1, nc)) for (i in 1:nr) {
    if (m[i,j]) { stack_i <- c(stack_i, i); stack_j <- c(stack_j, j) }
  }
  while (length(stack_i)) {
    li <- length(stack_i)
    ci <- stack_i[li]; cj <- stack_j[li]
    stack_i <- stack_i[-li]; stack_j <- stack_j[-li]
    if (ci < 1 || ci > nr || cj < 1 || cj > nc) next
    if (!m[ci,cj] || visited[ci,cj]) next
    visited[ci,cj] <- TRUE
    for (di in -1:1) for (dj in -1:1) {
      if (di == 0 && dj == 0) next
      stack_i <- c(stack_i, ci + di); stack_j <- c(stack_j, cj + dj)
    }
  }
  out <- m
  out[visited] <- FALSE
  return(out * 1)
}

# ---- safe dyn.load: silently skip missing libraries ----
safe_dyn_load <- function(paths) {
  for (p in paths) {
    if (file.exists(p)) {
      tryCatch(dyn.load(p, local = FALSE),
               error = function(e) message("Could not load ", p, ": ", e$message))
    }
  }
}

# ---- shared utility functions used by all scripts ----
imcrop <- function(p, toplim, leftlim, newheight, newwidth) {
  bottomlim <- toplim + newheight - 1
  rightlim  <- leftlim + newwidth - 1
  p[toplim:bottomlim, leftlim:rightlim]
}

fliplr <- function(p) {
  if (is.vector(p)) return(p[length(p):1])
  if (is.matrix(p)) return(p[, ncol(p):1])
  p
}

flipud <- function(p) {
  if (is.vector(p)) return(p[length(p):1])
  if (is.matrix(p)) return(p[nrow(p):1, ])
  p
}

meshgrid <- function(a, b) {
  list(x = outer(b * 0, a, FUN = "+"),
       y = outer(b, a * 0, FUN = "+"))
}

# ---- load MATLAB colour map with fallback ----
load_mycol <- function(path = "mycol.Rdata") {
  if (file.exists(path)) {
    e <- new.env()
    load(path, envir = e)
    if (exists("mycol", envir = e)) return(get("mycol", envir = e))
  }
  heat.colors(64)
}

# ---- helper to make output dir ----
ensure_dir <- function(d) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE)
  invisible(d)
}