# refcalvert.r
# Reads reference plane photo, computes deltapix0 and f0.
# Writes refdata.Rdata (for surfcolour.r) and calib.txt.

rm(list=ls())
times <- Sys.time()
graphics.off()

source("setup_helpers.r")
if (!requireNamespace("jpeg", quietly = TRUE)) install.packages("jpeg")
library(jpeg)

# ---- local helpers ----
myimage <- function(a, xpixel=1, ypixel=1) {
  nrows0 <- nrow(a); ncols0 <- ncol(a)
  fact <- max(1, round(nrows0/120))
  aplot <- a[seq(1, nrows0, fact), seq(1, ncols0, fact)]
  xplot <- seq(1, ncol(aplot)) * xpixel * fact
  yplot <- seq(1, nrow(aplot)) * ypixel * fact
  image(xplot, yplot, fliplr(t(aplot)), asp=1, xlab="", ylab="")
}

find_end <- function(x, frame=1, level=0) {
  n <- length(x)
  for (i in 1:(n-frame+1))
    if (all(x[i:(i+frame-1)] < level)) return(i)
  NULL
}
find_end2 <- function(x, frame=1, level=0) {
  n <- length(x)
  for (i in 1:(n-frame+1))
    if (all(x[i:(i+frame-1)] > level)) return(i)
  NULL
}

# ---- main ----
grgb0 <- read_jpeg_rgb("refplane.jpg")
gr0   <- grgb0[,,2]                     # green channel
imh0  <- nrow(gr0); imw0 <- ncol(gr0)

# find left/right of the calibration circle
rowmid <- round(imh0/2)
temp1  <- apply(grgb0[(rowmid-7):(rowmid+7),,1], 2, sum)
v1raw  <- which.min(temp1[1:round(imw0/2)])
v2raw  <- which.min(temp1[(round(imw0/2)+1):imh0]) + round(imw0/2)

av  <- sum(temp1[(v1raw-20):(v1raw+20)])/41
av2 <- sum(temp1[(v2raw-20):(v2raw+20)])/41

tempf <- ifelse(temp1 < av, 1, 0)
v1l <- find_end2(tempf[(v1raw-30):(v1raw+30)], 4, 0.5) + v1raw-30-1
v1r <- v1raw+30+1 - find_end2(tempf[(v1raw+30):(v1raw-30)], 4, 0.5)
tempf <- ifelse(temp1 < av2, 1, 0)
v2l <- find_end2(tempf[(v2raw-30):(v2raw+30)], 4, 0.5) + v2raw-30-1
v2r <- v2raw+30+1 - find_end2(tempf[(v2raw+30):(v2raw-30)], 4, 0.5)
v1h <- (v1r+v1l)/2
v2h <- (v2r+v2l)/2

deltapix0 <- 2*316/(v2r+v2l-v1r-v1l)

v1 <- round((imh0 - v2h + v1h)/2)
v2 <- round((imh0 + v2h - v1h)/2)
temp <- fft(gr0[v1:v2, round(imw0/2)])
klim <- round((v2-v1)/2)
k <- which.max(abs(temp[10:klim]))
k <- 9 + k - 1
pminus <- (abs(temp[k-1]))**2
pplus  <- (abs(temp[k+1]))**2
k0 <- k + (pplus-pminus)/(2*(pplus+pminus))
f0 <- k0/((v2-v1)*deltapix0)
cat(sprintf('Raw results %g %g %g %g\n', v1, v2, deltapix0, f0))

save(deltapix0, f0, gr0, file="refdata.Rdata")

zz <- file("calib.txt", "wt")
write(c(round(deltapix0,5), round(f0,5)), zz)
close(zz)

cat(sprintf('Run completed successfully\n'))
# END