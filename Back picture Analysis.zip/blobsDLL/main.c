/* This is the default source file for the blobs dynamic libraries.
Source file for labelling the UV blobs(much quicker than in R), and source for making a mask (similar
to rimage's thresholding, and no quicker)  */

int reduce(double *equiv, int ii) {
	if ((int)equiv[ii] == ii) {
		return ii;
	}
	else {
		return (reduce(equiv,equiv[ii]));
	}
}
	
/*labelling*/
void __declspec(dllexport) bwlabel2(double *img, int *ncols, int *nrows, double *imgout)
{
	int ii,jj,kk,nab,p0,count,found,outlabel,numberoflabels;
	int p[5]={0,0,0,0,0}; /* do not use p[0] or l[0]*/
	int l[5]={0,0,0,0,0};
	int blobcount=1;
	double equiv[257];
	double equivc[257];
	nab=(*ncols * *nrows);
	/*  initialise image out  */
/*	double imgout[nab];*/
	for (ii = 0; ii < nab; ii++){
		imgout[ii]=0.0;
	}
	/* initialise equiv (will not use equiv[0]=0) 
	   same for equivc */
	for (ii=0; ii<257; ii++){
		equiv[ii]=ii;
		equivc[ii]=0;
	}
	/*deal with first point (remember data here is zero based, R was one based) */
	if (img[0]){
		blobcount = blobcount+1;
		imgout[0] = 1;
	}
	/* scan down first column from second point (remember order of data is column wise but
	 passed	as one long vector from R)*/
	for (ii=1; ii < *nrows; ii++){
		if((img[ii]) && (img[ii-1])) imgout[ii] = imgout[ii-1];
		if((img[ii]) &&(img[ii-1]<0.1)) {
			imgout[ii]=(double)blobcount;
			blobcount=blobcount+1;
		}
	}
	/*scan remaining columns */
	for (jj=1; jj < *ncols; jj++){
		/*first top point of column */
		if ((img[jj**nrows]) && (img[(jj-1)**nrows])) imgout[jj**nrows]=imgout[(jj-1)**nrows];
		if ((img[jj**nrows]) && (img[(jj-1)**nrows+1])) imgout[jj**nrows]=imgout[(jj-1)**nrows+1];
		if ((img[jj**nrows]) && (img[(jj-1)**nrows]<0.1) && (img[(jj-1)**nrows+1]<0.1)) {
			imgout[jj**nrows]=(double)blobcount;
			blobcount = blobcount+1;
		}
		/* now remaining points in column */
		for (ii=1; ii < *nrows; ii++){
			p0 = (int)img[jj**nrows+ii];
			if (p0){
				/* get connected points (input) and labels (output) only if p0=1*/
				p[4] = (int)img[(jj-1)**nrows+ii-1]; /* northwest*/
				p[3] = (int)img[(jj-1)**nrows+ii]; /* west*/
				p[2] = (int)img[(jj-1)**nrows+ii+1]; /* southwest*/
				p[1] = (int)img[jj**nrows+ii-1]; /* north */
				l[4] = (int)imgout[(jj-1)**nrows+ii-1]; /* northwest*/
				l[3] = (int)imgout[(jj-1)**nrows+ii]; /* west*/
				l[2] = (int)imgout[(jj-1)**nrows+ii+1]; /* southwest*/
				l[1] = (int)imgout[jj**nrows+ii-1]; /* north */
				/* add up the labelled scanned points */
				count = p[1]+p[2]+p[3]+p[4];
				/*  all neighbouring labels equal zero, so give new label*/
				if (count == 0){
					outlabel = blobcount;
					blobcount = blobcount + 1;
				}
				/* only one neighbour has a label */
				if (count == 1){
					for (kk = 1; kk < 5; kk++){
						if (l[kk] != 0){
							outlabel = l[kk];
						}
					}
				}
				/* more than one labelled, use the lowest label found*/
				if (count > 1){
					/* first get minimum non-zero label */
					outlabel = 256;
					for (kk = 1; kk < 5; kk++){
						if (p[kk] != 0) {
							if (l[kk] < outlabel) {
								outlabel = l[kk];
							}
						}
					}
					/* then set up equivalences */
					for (kk = 1; kk < 5; kk++){
						if ((l[kk] != 0) && (l[kk] != outlabel)){
							if (outlabel < l[kk]){
								equiv[l[kk]] = (double)outlabel;
							}
						}
					}
				}
				imgout[jj**nrows+ii] = (double)outlabel;
			}
			/* otherwise if this point is zero do nothing*/
		}
	}
	
	
	/*  imgout is thus labelled with blobcount-1 labels and we have an equivalence table
	associating the equivalent labels */ 
	/* now reduce the equivalence table */
	numberoflabels = blobcount-1;
	for (ii = 1; ii < (numberoflabels+1); ii++){
		equiv[ii] = reduce(equiv,ii);
	}
	/* now compress the equivalence table*/
	count = 1;
	for (ii = 1; ii < (numberoflabels+1); ii++){
		if (ii==(int)equiv[ii]){
			equivc[ii] = count;
			count = count + 1;
		}
		if ((int)equivc[ii]==0) equivc[ii] = equivc[(int)equiv[ii]];
	}
	/* now run back through imgout replacing labels with their equivalences*/
	for (ii = 0; ii < nab; ii++){
		if (imgout[ii]){
			imgout[ii] = equivc[(int)imgout[ii]];
		}
	}

}
	

		
/* make a mask */
void makemask(double *img, int *ncols, int *nrows, int *thresh, double *imgout)
{
	int ii,nab;
	nab = *ncols**nrows;
	/*  initialise image out  */
	for (ii = 0; ii < nab; ii++){
		imgout[ii]=0.0;
	}
	for (ii = 0; ii < nab; ii++){
		if (img[ii] > *thresh) imgout[ii] = 1;
	}
}
