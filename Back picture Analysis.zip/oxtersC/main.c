/* This is the default source file for new dynamic libraries. */
/* source file for locating position of oxters and excising arms */
void excise(double *maskin, int *ncols, int *nrows, double *maskout)
{
	int ii,jj,nab;
	nab=(*ncols * *nrows);
	/*  initialise maskout  */
	for (ii = 0; ii < nab; ii++){
		maskout[ii]=maskin[ii];
	}
	/*process bit of mask with lower arms and possibly hips */
	for (ii = 0; ii < *nrows; ii++){
		for (jj=1; jj < *ncols; jj++){
			if (maskout[*nrows*jj+ii]>0.9){
				if (maskout[*nrows*(jj-1)+ii]<0.1){
					maskout[*nrows*jj+ii]=0.0;
				}
			}
		}
	}
}
	
	
